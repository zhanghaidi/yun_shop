<div  class="panel panel-info">
    <ul class="add-shopnav" id="myTab">
        <li class="active" ><a href="#tab_basic">个人信息</a></li>
        <li><a href="#tab_pay">收款信息</a></li>
    </ul>
</div>