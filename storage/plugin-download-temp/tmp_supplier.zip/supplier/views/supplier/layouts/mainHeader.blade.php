<div class="main-panel">
    @include('public.admin.message')
    <div class="content">
        @yield('content')
    </div>
</div>