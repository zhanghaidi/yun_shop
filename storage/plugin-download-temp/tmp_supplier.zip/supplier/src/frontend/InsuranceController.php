<?php
/**
 * Created by PhpStorm.
 * User: yunzhong
 * Date: 2019/4/8
 * Time: 10:18
 */

namespace Yunshop\Supplier\frontend;



use app\common\components\ApiController;
use Yunshop\Supplier\admin\models\Supplier;
use Yunshop\Supplier\common\models\Insurance;
use Yunshop\Supplier\common\services\InsuranceService;


class InsuranceController extends ApiController
{
    /**
     * 个人中心表单列表
     */
    public function index()
    {
        $member_id = \YunShop::app()->getMemberId();

        $memberSupplier = Supplier::uniacid()->where('member_id',$member_id)->first();
        if (empty($memberSupplier)) {
            return $this->errorJson('没有权限,跳转供应商申请!', ['url'=> yzAppFullUrl('member/supplier')]);
        }

        $data = Insurance::memberInsurance($member_id);
        return $this->successJson('ok', $data);
    }

    public function insuranceDetail()
    {
       $id = \Yunshop::request()->id;
       $data = Insurance::find($id);
//       $data = InsuranceService::addressTranslation($data);
       if (!$data){
          return $this->errorJson('找不到保单记录');
       }
       return $this->successJson('ok',$data);
    }

    /***
     * 存储保单修改数据
     */
    public function insuranceEdit()
    {
        $id = \Yunshop::request()->id;
        $data = \Yunshop::request()->data;
        $insurance_model = Insurance::find($id);

        if ($data){
            $insurance_model->setRawAttributes($data);
            $validator = $insurance_model->validator($insurance_model->getAttributes());

            if ($validator->fails()) {
                return $this->error($validator->messages());
            } else {
                if ($insurance_model->save()) {
                    //显示信息并跳转
                    return $this->successJson('修改成功');
                } else {
                    return $this->errorJson('修改失败');
                }
            }
        }
        if ($insurance_model){
            return $this->successJson('查询数据成功',$insurance_model);
        }else{
            return $this->errorJson('找不到数据');
        }

    }

    /***
     * 存储保单添加数据
     */
    public function insuranceAdd()
    {
        $data = \Yunshop::request()->data;

        if ($data){
//        $data = [
//            "serial_number" => "22",
//              "shop_name" => "22",
//              "insured" => "222",
//              "identification_number" => "450821199603140230",
//              "phone" => "15677222146",
//              "address" => "22",
//              "insured_property" => "22",
//              "customer_type" => "22",
//              "insured_amount" => "22",
//              "guarantee_period" => "22",
//              "premium" => "222",
//              "insurance_coverage" => "22",
//              "additional_glass_risk" => "22",
//              "insurance_company" => "22",
//              "note" => "222",
//        ];
            $memberSupplier = Supplier::uniacid()->where('member_id',\YunShop::app()->getMemberId())->first();
            $data['supplier_id'] = $memberSupplier->id;//Session::get('supplier')['id'];
            $data['uniacid'] = \Yunshop::app()->uniacid;
            $insurance = new Insurance();

            $insurance->setRawAttributes($data);
            $validator = $insurance->validator($insurance->getAttributes());
//        dd($insurance);
            if ($validator->fails()) {
                dd($insurance);
                //检测失败
                return $this->errorJson('添加失败');
            } else {
                //数据保存
                if ($insurance->save()) {
                    return $this->successJson('添加成功');
                }
            }

        }else{
            return $this->errorJson('数据为空，添加失败');
        }
    }

    /**
     * 删除保单
     */
    public function insuranceDel()
    {
        $id = intval(\Yunshop::request()->id);
        $insurance_model = Insurance::find($id);
        if (!$insurance_model) {
            return $this->errorJson('无记录或已被删除');
        }


        if ($insurance_model->delete()) {
            return $this->successJson('删除成功');
        }
        return $this->errorJson('删除失败', '', 'error');
    }

}