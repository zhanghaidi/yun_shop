<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2018/11/26
 * Time: 3:51 PM
 */

namespace Yunshop\Supplier\common\modules\orderGoods;

use app\frontend\modules\orderGoods\models\PreOrderGoodsCollection;

class OrderGoodsCollection extends PreOrderGoodsCollection
{

}