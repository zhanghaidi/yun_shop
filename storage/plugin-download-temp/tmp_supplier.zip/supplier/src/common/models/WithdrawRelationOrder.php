<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/27
 * Time: 下午9:42
 */

namespace Yunshop\Supplier\common\models;


use app\common\models\BaseModel;

class WithdrawRelationOrder extends BaseModel
{
    public $table = 'yz_withdraw_relation_order';
    protected $guarded = [''];
}