<?php

/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/22
 * Time: 下午8:19
 */

namespace Yunshop\Supplier\admin\models;


class Supplier extends \Yunshop\Supplier\common\models\Supplier
{

}