<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/22
 * Time: 下午8:22
 */

namespace Yunshop\Supplier\admin\models;


class SupplierGoods extends \Yunshop\Supplier\common\models\SupplierGoods
{

}