<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/22
 * Time: 下午8:23
 */

namespace Yunshop\Supplier\admin\models;


class SupplierOrderJoinOrder extends \Yunshop\Supplier\common\models\SupplierOrderJoinOrder
{

}