<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/24
 * Time: 下午6:18
 */

namespace Yunshop\Supplier\admin\models;



class SupplierGoodsJoinGoods extends \Yunshop\Supplier\common\models\SupplierGoodsJoinGoods
{

}