<?php
/**
 * Created by PhpStorm.
 * User: yunzhong
 * Date: 2019/4/3
 * Time: 16:30
 */

namespace Yunshop\Supplier\admin\controllers\insurance;

use app\common\components\BaseController;
use Yunshop\Supplier\common\models\Insurance;
use Yunshop\Supplier\common\services\InsuranceService;
use app\common\helpers\PaginationHelper;
use app\common\helpers\Url;

class InsuranceController extends BaseController
{

    public function index()
    {

        $params = \YunShop::request()->get('search');

        $insuranceModel = Insurance::queryData($params);  
        $list = $insuranceModel->orderBy('id', 'desc')->paginate(10)->toArray();
        $list['data'] = InsuranceService::addressTranslation($list['data']);
        $pager = PaginationHelper::show($list['total'], $list['current_page'], $list['per_page']);
        return view('Yunshop\Supplier::admin.insurance.insurance_list',[
            'data'          => $list['data'],
            'pager'         => $pager,
            'search'       => $params
        ]);
    }


    /**
     * 导出表格
     */
    public function export()
    {
        $params = \YunShop::request()->get('search');
        $export_data[0] = ['序号', '供应商账号','店面名称','被保险人','证件号码','被保险人联系方式','保险详细地址'
            ,'投保财产(需如实填写)','用户类型','保额 （万元）','保险期限 (年)','保费（元）','投保险种（1、火险+盗抢。   2、单独盗抢）','附加玻璃险（35元保1万）份','投保人（安防公司）','创建时间','备注'];
        $child = InsuranceService::addressTranslation(Insurance::queryData($params)->get());
        foreach ($child as $key => $item) {
            $insurance = $item;
            $export_data[$key + 1] = [
                $insurance->serial_number,
                $insurance->supplier->username,
                $insurance->shop_name,
                $insurance->insured,
                ' '.$insurance->identification_number,
                $insurance->phone,
                $insurance->address,
                $insurance->insured_property,
                $insurance->customer_type,
                $insurance->insured_amount,
                $insurance->guarantee_period,
                $insurance->premium,
                $insurance->insurance_coverage,
                $insurance->additional_glass_risk,
                $insurance->insurance_company,
                $insurance->created_at,
                $insurance->note,
            ];
        }
        \Excel::create('保单数据模板', function ($excel) use ($export_data) {
            $excel->setTitle('Office 2005 XLSX Document');
            $excel->setCreator('芸众商城')
                ->setLastModifiedBy("芸众商城")
                ->setSubject("Office 2005 XLSX Test Document")
                ->setDescription("Test document for Office 2005 XLSX, generated using PHP classes.")
                ->setKeywords("office 2005 openxml php")
                ->setCategory("report file");
            $excel->sheet('info', function ($sheet) use ($export_data) {
                $sheet->rows($export_data);
            });
        })->export('xls');
    }


    /***
     * 存储保单修改数据
     */
    public function insuranceEdit()
    {
        $id = \Yunshop::request()->id;
        $data = \Yunshop::request()->data;
        $insurance_model = Insurance::find($id);

        if ($data){
            $insurance_model->setRawAttributes($data);
            $validator = $insurance_model->validator($insurance_model->getAttributes());

            if ($validator->fails()) {
                $this->error($validator->messages());
            } else {
                if ($insurance_model->save()) {
                    //显示信息并跳转
                    return $this->message('修改成功',Url::absoluteWeb('plugin.supplier.admin.controllers.insurance.insurance.index'));
                } else {
                    return $this->error('修改失败');
                }
            }
        }

        return view('Yunshop\Supplier::supplier.insurance.insurance_edit',[
            'data'      => $insurance_model
        ]);
    }

    /**
     * 删除保单
     */
    public function insuranceDel()
    {
        $id = intval(\Yunshop::request()->id);
        $insurance_model = Insurance::find($id);
        if (!$insurance_model) {
            return $this->message('无记录或已被删除', '', 'error');
        }


        if ($insurance_model->delete()) {
            return $this->message('删除成功');
        }
        return $this->message('删除失败', '', 'error');
    }


}