<?php

/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/4/13
 * Time: 上午11:46
 */

namespace Yunshop\Supplier\common\services;

class VerifyDataService
{
    public static function verifyData()
    {

    }
}