<?php

/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/25
 * Time: 上午10:06
 */

namespace Yunshop\Supplier\supplier\models;

class SupplierOrderJoinOrder extends \Yunshop\Supplier\common\models\SupplierOrderJoinOrder
{

}