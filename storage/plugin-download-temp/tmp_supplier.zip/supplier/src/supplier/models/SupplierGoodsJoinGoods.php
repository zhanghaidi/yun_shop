<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/25
 * Time: 上午11:49
 */

namespace Yunshop\Supplier\supplier\models;


class SupplierGoodsJoinGoods extends \Yunshop\Supplier\common\models\SupplierGoodsJoinGoods
{

}