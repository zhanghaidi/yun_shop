<div  class="top">
    <ul class="add-shopnav" id="myTab">
        <li class="active" ><a href="#tab_setinfo" class="tab">基础设置</a></li>
        <!-- <li><a href="#tab_alipay" class="tab">支付宝应用信息</a></li> -->
    </ul>
</div>
