<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/7/3
 * Time: 16:12
 */

namespace Yunshop\AlipayOnekeyLogin\services\infosynchro;

use Illuminate\Support\Facades\DB;
use app\frontend\modules\member\models\MemberUniqueModel;
use app\frontend\modules\member\models\MemberWechatModel;
use Exception;



class YdbAppUserService extends MemberInfoService
{
    protected $wechat_sign = 'ydbApp';

    public function updateMember($old_member, $new_member)
    {

        //Third party

        $wechat_user = MemberWechatModel::uniacid()->where('member_id', $new_member->uid)->first();

        if (empty($wechat_user)) {
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据未找到uid:'.$new_member->uid);
            return false;
        }


        if (!$this->existMember($old_member->uid)) {
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据new_uid='.$new_member->uid.',  old_uid:'.$old_member->uid.'不是支付宝会员');
            return false;
        }

        $unique_info = MemberUniqueModel::uniacid()->where('member_id', $wechat_user->member_id)->first();

        \Log::debug('微信'.$this->wechat_sign.'同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid);

        try {
            DB::beginTransaction();

            $wechat_user->member_id = $old_member->uid;

            if(!$wechat_user->save()) {
                throw new Exception("yz_member_wechat表信息修改失败");
            }
            if ($unique_info) {
                \Log::debug('微信开放平台-newUID:'.$new_member->uid.'-oldUID:'.$old_member->uid);
                $unique_info->member_id = $old_member->uid;
                $unique_info->save();
            }
            $status = $this->deleteMember($new_member);
            if (!$status) {
                \Log::debug('删除同步用户信息失败,oldID:'.$old_member->uid.'-newID:'.$new_member->uid);
                throw new Exception("删除new用户信息失败");
            }
            $this->setSession($old_member->uid);
            DB::commit();
            $this->insertMergeLog('微信'.$this->wechat_sign, $old_member, $new_member);
            return true;
        } catch (Exception $e) {
            DB::rollBack();
            $this->insertMergeLog('微信'.$this->wechat_sign.':'.$e->getMessage(), $old_member, $new_member, 1);
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据uid:'.$new_member->uid.'失败');
            return false;
        }
    }

    //抛弃
    public function old($old_member, $new_member)
    {

        //Third party

        $wechat_user = MemberWechatModel::uniacid()->where('member_id', $new_member->uid)->first();

        if (empty($wechat_user)) {
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据未找到uid:'.$new_member->uid);
            return false;
        }


        if (!is_null(MemberWechatModel::uniacid()->where('member_id', $old_member->uid)->first())) {
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid.'平台相同');
            return false;
        }

        $unique_info = MemberUniqueModel::uniacid()->where('member_id', $wechat_user->member_id)->first();

        \Log::debug('微信'.$this->wechat_sign.'同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid);

        try {
            DB::beginTransaction();

            $wechat_user->member_id = $old_member->uid;

            if(!$wechat_user->save()) {
                throw new Exception("yz_member_wechat表信息修改失败");
            }
            if ($unique_info) {
                \Log::debug('微信开放平台-newUID:'.$new_member->uid.'-oldUID:'.$old_member->uid);
                $unique_info->member_id = $old_member->uid;
                $unique_info->save();
            }
            $status = $this->deleteMember($new_member);
            if (!$status) {
                \Log::debug('删除同步用户信息失败,oldID:'.$old_member->uid.'-newID:'.$new_member->uid);
                throw new Exception("删除new用户信息失败");
            }
            $this->setSession($old_member->uid);
            DB::commit();
            $this->insertMergeLog('微信'.$this->wechat_sign, $old_member, $new_member);
            return true;
        } catch (Exception $e) {
            DB::rollBack();
            $this->insertMergeLog('微信'.$this->wechat_sign.':'.$e->getMessage(), $old_member, $new_member, 1);
            \Log::debug('微信'.$this->wechat_sign.'同步会员数据uid:'.$new_member->uid.'失败');
            return false;
        }
    }
}