<?php

namespace Yunshop\AlipayOnekeyLogin\services\infosynchro;

use Illuminate\Support\Facades\DB;
use Yunshop\AlipayOnekeyLogin\models\MemberAlipay;
use Exception;
/**
* create 2018/6/18 
*/
class AlipayUserService extends MemberInfoService
{
	public function updateMember($old_member, $new_member)
	{

		$alipay_member = MemberAlipay::uniacid()->where('member_id', $new_member->uid)->first();

        if (empty($alipay_member)) {
            \Log::debug('支付宝同步会员数据未找到uid:'.$new_member->uid);
            return false;
        }

        if ($this->existMember($old_member->uid)) {
            \Log::debug('支付宝同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid.'都是支付宝用户无法同步');
            return false;
        }

        \Log::debug('支付宝同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid);

        try {
            DB::beginTransaction();
            $alipay_member->member_id = $old_member->uid;

            if(!$alipay_member->save()) {
                throw new Exception("yz_member_alipay表信息修改失败");
            }

            $status = $this->deleteMember($new_member);
            if (!$status) {
                \Log::debug('删除同步用户信息失败,oldID:'.$old_member->uid.'-newID:'.$new_member->uid);
                throw new Exception("删除new用户信息失败");
            }
            $this->setSession($old_member->uid);
            DB::commit();
            $this->insertMergeLog('支付宝', $old_member, $new_member);
            return true;
        } catch (Exception $e) {
        	DB::rollBack();
            $this->insertMergeLog('支付宝:'.$e->getMessage(), $old_member, $new_member, 1);
            return false;
        }
	}

    //抛弃
    public function old($old_member, $new_member)
    {

        $alipay_member = MemberAlipay::uniacid()->where('member_id', $new_member->uid)->first();

        if (empty($alipay_member)) {
            \Log::debug('支付宝同步会员数据未找到uid:'.$new_member->uid);
            return false;
        }

        if (!is_null(MemberAlipay::uniacid()->where('member_id', $old_member->uid)->first())) {
            \Log::debug('支付宝同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid.'平台相同');
            return false;
        }

        \Log::debug('支付宝同步会员数据new_uid:'.$new_member->uid.'-old_uid:'.$old_member->uid);

        try {
            DB::beginTransaction();
            $alipay_member->member_id = $old_member->uid;

            if(!$alipay_member->save()) {
                throw new Exception("yz_member_alipay表信息修改失败");
            }

            $status = $this->deleteMember($new_member);
            if (!$status) {
                \Log::debug('删除同步用户信息失败,oldID:'.$old_member->uid.'-newID:'.$new_member->uid);
                throw new Exception("删除new用户信息失败");
            }
            $this->setSession($old_member->uid);
            DB::commit();
            $this->insertMergeLog('支付宝', $old_member, $new_member);
            return true;
        } catch (Exception $e) {
            DB::rollBack();
            $this->insertMergeLog('支付宝:'.$e->getMessage(), $old_member, $new_member, 1);
            return false;
        }
    }
}