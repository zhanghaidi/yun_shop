<div class="panel panel-info">
    <ul class="add-shopnav">
        <li><a href="{{ yzWebUrl('plugin.article.admin.article.index') }}" style="cursor: pointer;">普通文章管理</a></li>
        <li><a href="{{ yzWebUrl('plugin.article.admin.article.audioArticle') }}" style="cursor: pointer;">音频文章管理</a></li>
    </ul>
</div>


