
"use strict";

$.extend($.locales['en'], {
    'article': {
        test: "JavaScript i18n test: English"
    }
});
